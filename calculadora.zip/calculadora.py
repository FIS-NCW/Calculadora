class Calculadora:
    def suma(self,a,b):
        return a+b

    def resta(self,a,b):
        return a-b

    def multiplicar(self,a,b):
        return a*b

    def dividir(self,a,b):
        return a/b

    def potencia(self,a,b):
        return pow(a,b)