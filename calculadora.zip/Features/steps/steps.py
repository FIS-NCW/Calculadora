from behave import *
from FIS import calculadora
##Suma
@given ('a {values} to sum')
def step_imp(context, values):
    context.calculadora = calculadora.Calculadora()
    context.values = [int(x) for x in values.split(",")]

@when ('the calc sum the values')
def step_imp(context):
    context.total = context.calculadora.suma(context.values[0],context.values[1])

@then ('the {total:d} of sum is ok')
def step_imp(context,total):
    assert (context.total == total)

##Resta

@given ('the {values} to substract')
def step_imp(context, values):
    context.calculadora = calculadora.Calculadora()
    context.values = [int(x) for x in values.split(",")]

@when ('the calc substract the values')
def step_imp(context):
    context.total = context.calculadora.resta(context.values[0],context.values[1])

@then ('the {total:d} of substract is ok')
def step_imp(context,total):
    assert (context.total == total)

##Multiplicacion

@given ('the {values} to multiplier')
def step_imp(context, values):
    context.calculadora = calculadora.Calculadora()
    context.values = [int(x) for x in values.split(",")]

@when ('the calc multiplier the values')
def step_imp(context):
    context.total = context.calculadora.multiplicar(context.values[0],context.values[1])

@then ('the {total:d} of multiplier is ok')
def step_imp(context,total):
    assert (context.total == total)

##Division

@given ('the {values} to divide')
def step_imp(context, values):
    context.calculadora = calculadora.Calculadora()
    context.values = [int(x) for x in values.split(",")]

@when ('the calc divide the values')
def step_imp(context):
    context.total = context.calculadora.dividir(context.values[0],context.values[1])

@then ('the {total:d} of divide is ok')
def step_imp(context,total):
    assert (context.total == total)

##Potencia

@given ('the {values} to pow')
def step_imp(context, values):
    context.calculadora = calculadora.Calculadora()
    context.values = [int(x) for x in values.split(",")]

@when ('the calc pow the values')
def step_imp(context):
    context.total = context.calculadora.potencia(context.values[0],context.values[1])

@then ('the {total:d} of pow is ok')
def step_imp(context,total):
    assert (context.total == total)

